---
title: "How To Process Audio"
category: "Imported"
tags: ["imported", "pptx", "presentation"]
creator: "converter"
created: "2025-12-15"
description: "Imported from How-To Audio Processing.pptx"
---

## Step 1: How To Process Audio

![Slide 1](how-to-audio-processing/images/slide-01.jpg)



## Step 2: Owner

![Slide 2](how-to-audio-processing/images/slide-01.jpg)

 
name
Don Burnside
Team
DnD
R
esources
Tools
Adobe Audition
Description
Basic audio processing for volume and noise correction
AU 
Member
 
AU 
Member
 
AU 
Member
 
AU 
Member
 
AU 
Member
 
AU 
Member
 
AU 
Member
 
AU 
Member
 
AU 
Member
 
Date
Process Info

## Step 3: Right click the audio track in PowerPoint and choose save media as. Save the audio track to a local folder, call it slide XX where xx is the slide number. 

![Slide 3](how-to-audio-processing/images/slide-02.jpg)

Once all audio tracks have been saved, go back and remove them from the 
powerpoint
 deck and save it. Remove any page numbers at this time as well. 
Open Adobe Audition
Step 1

## Step 4: Drag audio files into Audition

![Slide 4](how-to-audio-processing/images/slide-02.jpg)

Step 2

## Step 5: Click on Match Loudness

![Slide 5](how-to-audio-processing/images/slide-03.jpg)

Select all audio tracks and drag them into drop area
Set Match To 
to
 ITU-R BS.1770-3 Loudness using the drop down
Set Target Loudness to -14 LUFS
Click Run
Step 3 – Match Loudness

## Step 6: Double click a track to select it

![Slide 6](how-to-audio-processing/images/slide-03.jpg)

Click Diagnostics tab, select 
DeClicker
 from Effect drop down
Click Scan
Click Repair All
Repeat for all tracks.
Step 4 - 
DeClicker

## Step 7: Click File —&gt; Save All

![Slide 7](how-to-audio-processing/images/slide-04.jpg)

If prompted, confirm file save location. File type should be .wav by default, if not, change it for best results
Repeat for all tracks
Once saved, drag back into 
the PowerPoint Deck
Step 5 – Save All

## Step 8: The preceding steps can be used to process audio from Videos in Adobe Premier

![Slide 8](how-to-audio-processing/images/slide-04.jpg)

It is best to process audio 
first
 before editing video
After processing, save the audio file and it will update in Premier automatically, then continue to edit and 
expor
 normally
Notes: Video
